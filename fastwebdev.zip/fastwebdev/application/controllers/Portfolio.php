<?php 
class Portfolio extends CI_Controller{
     public function __construct(){
     	parent::__construct();
		$this->load->model('Register_model');
		$this->load->model('Portfolio_model');
     
		
     
}
	public function index(){

		 $newdata = array();
		$newdata  = $this->session->all_userdata();	
		$data['title'] ='Portofolio FastWebDev';
		$this->load->view('header/header',  $data);
		($this->session->userdata('logged_in')==true) ? 
		$this->load->view('body/content', $newdata['username']):
		$this->load->view('body/body');		$this->load->view('footer/footer');
	}
	public function contact(){
		
		$data = array(
			'name'=>$this->input->post('name'),
		    	'email'=>$this->input->post('email'),
			'phone'=>$this->input->post('phone'),
			'message'=>$this->input->post('message'),
		);
	

	$to 	 = "office@fastwebdev.xyz";
	$subject = $data['name'];
	$message = $data['message'];
	$headers = "From:". $data['email'];

	mail($to,$subject,$message,$headers);

        $insert = $this->Portfolio_model->contact($data);
      
	}
	
	public function login(){
	
		
		$email  = $this->input->post('email');
		$password  = md5($this->input->post('password'));
   
	   
		$result  = $this->Register_model->login($email, $password);
	 
		if($result==true){
			foreach($result as $row){
				 $newdata = array(
                   'username'  => $row->username,
                   'logged_in' => TRUE
               );
			}
		}else{
			$newdata = array();
		}
	    if($result == false){
	    	$array = array(
				       
						"message" => "Wrong password/username",
						"success"=>false
				);
				$error['json'] = $array;
				echo json_encode($error);   
	    }else {
			$this->session->set_userdata($newdata);
			 $newdata  = $this->session->all_userdata();
	    	$array = array(
						"success"=>true,
						"message" => "Welcome ".$newdata['username']
				);
			
				$success['json'] = $array;
				
				echo json_encode($success);   
		}
	}
	public function checkUser(){
		

		if($this->input->post('username') || md5($this->input->post('password')) !='' || $this->input->post('email') ){
			$input = array(
					'username'=>$this->input->post('username'),
					'password'=> md5($this->input->post('password')),
					'email'   => $this->input->post('email')
			);
		}else{
			$this->redirect('/');
			$empty_fields = array(
						"success"=>true,
						"message" => "Empty fields"
					);
					$error['json'] = $empty_fields;
					echo json_encode($error);   
		}

		$already_exist = $this->Register_model->getByUser($input['username'], $input['email']);
      
			if(!empty($already_exist[0]->username) && $already_exist[0]->username == $input['username']){
				$username_exist = array (
					'message'=>'This username is already used',
					"success"=>false
				);
				$success['json'] = $username_exist;
				echo json_encode($success);   
		
			} else if ( !empty($already_exist[0]->email) && $already_exist[0]->email == $input['email'] ){
				$email_exist = array (
					'message'=>'This email is already used',
					"success"=>false
				);
				$success['json'] = $email_exist;
				echo json_encode($success);   
				
			} else {
				$this->Register_model->insert($input);
				$newdata = array(
                   'username'  => $input['username'],
                   'logged_in' => TRUE
               );
			   $this->session->set_userdata($newdata);
				$successufully_registered = array (
					'message'=>'Successufully registerd',
					'success'=>true
				);
				$success['json'] = $successufully_registered;
				echo json_encode($success);   
				}

	}

	public function password_forgetten(){
		if($this->input->post('email') !=''){
			$email = $this->input->post('email');
	
			$data = array(
				'email'=> $email
			);
			$recoverPassword = $this->Portfolio_model->recoverPaassword($data['email']);
			
		   $newpassword =  md5($recoverPassword[0]->password);
			$data = array(
				'email'=> $email,
				'password'=> $newpassword
			);
		   $insert_new_password = $this->Portfolio_model->insert_new_password($data, $email);
			
		    $to = $email;
			$subject = "New Password";

			$message = "
			<html>
			<head>
			<title>Your password</title>
			</head>
			<body>
			<p>This email contains fastwebdev account password!</p>
			<table>
			<tr>
			<th>Email</th>
			<th>Password</th>
			</tr>
			<tr>
			<td>".$email."</td>
			<td>".$newpassword."</td>
			</tr>
			</table>
			</body>
			</html>
			";
		
		// Always set content-type when sending HTML email
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

		// More headers
		$headers .= 'From: <office@fastwebdev.xyz> '. "\r\n";

		$email_send = mail($to,$subject,$message,$headers);
	
		if($email_send){
			$email_with_password = array(
				'message'=>'A message with new password has been sent to your email',
				"success"=>true
			);
		}
		$success['json'] = $email_with_password;
		echo json_encode($success);
		}
	}	





	public function newsletter(){
		$this->load->model('Subscribe_model');
		$email = $this->input->post('email');
					

		$check_if_exist = $this->Subscribe_model->check_if_exist($email);

		if($check_if_exist == true){
			$subscribe_success = array(
				'message'=>'Your email is already subscribed for newletters',
				"success"=>false
			);
			$success['json'] = $subscribe_success;
			echo json_encode($success);

		
		}else{

		$data = array(
				'email' => $this->input->post('email')
			);
		 $this->Subscribe_model->subscribe($data);

			$subscribe_success = array(
				'message'=>'You successufully subscribed to fastwebdev.xyz',
				"success"=>true
			);
			$success['json'] = $subscribe_success;
			echo json_encode($success);

		

	}
}
		public function logout(){
		$this->session->unset_userdata('logged_in');
		$this->session->sess_destroy();
	}
}

?>