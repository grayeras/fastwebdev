<?php





class Subscribe_model extends CI_Model{

	function __construct()

    {

        parent::__construct();

    }

  public function check_if_exist($email){

     	$this->db->select('email');
	$this->db->from('subscribers');
	$this->db->where('email', $email);
	$query = $this->db->get();		
		if($query->num_rows()>0){
			return true;

		}else{
			return false;
		

		}
      


	
	
 }
    public function insert($data){

        $this->db->insert('users', $data); 

    }
 public function subscribe($data){

	$query = $this->db->insert('subscribers', $data);	
	

     }

    public function getByUser($username){

    	

	    $query = $this->db->query("SELECT username FROM users where username= '.$username.'");

		if($query->result==1){

			echo 'exist';

		}

/* 		foreach ($query->result('User') as $row){

			   echo $row->name; // call attributes

			   echo $row->reverse_name(); // or methods defined on the 'User' class

		} 

 */    }

      



}