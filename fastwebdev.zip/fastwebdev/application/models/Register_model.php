<?php


class Register_model extends CI_Model{
	function __construct()
    {
        parent::__construct();
    }
   public function login($email, $password){
   $query = $this->db->select('*')->from('users')->where("email ='$email' && password='$password'")->get();
   	if($query->num_rows()>0){
   		return $query->result();
   	}else{
   		return false;
   	}
   }
    public function insert($data){
        $this->db->insert('users', $data); 
		
    }
     public function getByUser($username, $email){
        
     	$query = $this->db->select('*')->from('users')->where("username ='$username' or email='$email'")->get();
		
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return false;
		}
		
    }
      

}