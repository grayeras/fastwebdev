<?php





class Portfolio_model extends CI_Model{

	function __construct()

    {

        parent::__construct();

    }

  

    public function contact($data){

        $this->db->insert('contact', $data); 

    }

    

     public function login(){

     	$this->db->get('users', $data);

     }

       public function insert_new_password($data, $email){
		$this->db->where('email',$email);
		$this->db->update('users', $data); 
	 }
	 public function recoverPaassword($email){
		$query = $this->db->select('*')->from('users')->where("email='$email'")->get();
		
		if($query->num_rows()>0){
			return $query->result();
		}else{
			return false;
		}
	 }

     public function register(){

     	$this->db->insert('users', $data);

     }

      



}